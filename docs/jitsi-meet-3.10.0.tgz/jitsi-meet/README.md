# Helm Chart for Jitsi Meet

[![Artifact Hub](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/jitsi-meet)](https://artifacthub.io/packages/search?repo=jitsi-meet)
[![CNTi cert](https://img.shields.io/github/actions/workflow/status/jitsi-contrib/jitsi-helm/cnti.yml?label=CNTi%20cert&logo=data:image/svg%2bxml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA5OS4yMSA2OS4zOSIgZmlsbD0iI2ZmZiI+PHBhdGggZD0iTTgwLjgzLDI0LjcxdjcuNjJjNi4zNCwxLjksMTAuOTcsNy43OCwxMC45NywxNC43MnMtNC41OSwxMi43Ny0xMC44OSwxNC42OXY3LjY0YzEwLjQzLTIuMDgsMTguMzEtMTEuMzEsMTguMzEtMjIuMzRzLTcuOTItMjAuMjktMTguMzktMjIuMzRaIi8+PHBhdGggZD0iTTIxLjgyLDYxLjg2aC00LjUxYy0uMTYtLjAyLS4zOS0uMDMtLjU1LS4wNC0uMTctLjAxLS40Ny0uMDItLjYzLS4wNi0uNjEtLjA5LTEuMzEtLjIyLTEuODktLjQxLTQuNDktMS4zOS03LjYzLTUuODgtNi42Ni0xMC41OCwxLjY2LTcuNzEsMTEuNzUtMTAuMSwxNy4yNS00Ljc5bDUuNjYtNC43M2MtMi4yLTMuNDQtMy40My03LjQzLTMuNTQtMTEuNDktLjIzLTcuMzIsMy4xNS0xNC4zMyw5LjQ1LTE4LjIsNi43Ni00LjE3LDE2LjE1LTQuNDQsMjMuMTktLjgxLDMuOTIsMi4wMyw2Ljg2LDUuNDYsOC4zNyw5LjU1aDguNzFjLS4xMy0uNTktLjI5LTEuMTctLjQ4LTEuNzUtMi4wMy02LjQzLTYuNzUtMTIuMS0xMi43NS0xNS4xNEM1OS41MywxLjM3LDU1LjE3LjMyLDUwLjgyLjA4Yy0xNy42NC0xLjIyLTMyLjUxLDExLjk2LTMxLjYxLDI5Ljk4LjA5LDEuOTYuMzgsMy45MS44Niw1LjgyLTUtLjY5LTEwLjI2LjcyLTE0LjEzLDQuMDJDMi41MSw0Mi43NS4yNCw0Ny4wOC4wMyw1MS41NWMtLjU2LDEwLjI3LDguMTksMTguMDUsMTguMiwxNy43M2gxLjc0cy42NywwLDEuODYsMHYtNy40MloiLz48cmVjdCB4PSI2OC4yMyIgeT0iMjQuMTkiIHdpZHRoPSI4Ljg2IiBoZWlnaHQ9IjQ1LjE3Ii8+PHJlY3QgeD0iNTQuMTciIHk9IjMzLjA2IiB3aWR0aD0iOC45IiBoZWlnaHQ9IjM2LjMiLz48cmVjdCB4PSI0MC4xNSIgeT0iNDIuMTciIHdpZHRoPSI4Ljg5IiBoZWlnaHQ9IjI3LjIiLz48cmVjdCB4PSIyNi4wOSIgeT0iNTEuMjMiIHdpZHRoPSI4LjkzIiBoZWlnaHQ9IjE4LjEzIi8+PC9zdmc+Cg==)](https://github.com/jitsi-contrib/jitsi-helm/actions/workflows/cnti.yml)
![GitHub Release](https://img.shields.io/github/v/release/jitsi-contrib/jitsi-helm?logo=helm&logoColor=white&label=Latest%20release)
![GitHub Release Date](https://img.shields.io/github/release-date/jitsi-contrib/jitsi-helm?display_date=published_at&logo=git&logoColor=white&label=Released%20at)

- [Prerequisites](#prerequisites)
- [Quick start](#quick-start)
- [Exposing your Jitsi Meet installation](#exposing-your-jitsi-meet-installation)
- [Recording and streaming support](#recording-and-streaming-support)
- [Transcription support](#transcription-support)
- [Scaling your installation](#scaling-your-installation)
- [Adding custom Prosody plugins](#adding-custom-prosody-plugins)
- [Documentation](#documentation)

[Jitsi-Meet](https://jitsi.org/jitsi-meet/): Secure, simple and scalable video
conferences that you can use as a standalone app or embed in your web
application.

This chart bootstraps a Jitsi Meet stack on Kubernetes.

See also [jitsi-scaler](https://github.com/jitsi-contrib/jitsi-scaler) for a
Jitsi Meet stack containing multiple shards.

## Prerequisites

- A Kubernetes cluster and Helm 3.8+ (3.8+ is required for the OCI install).
- A way to expose JVB media to participants (see the Exposing section below).
- cert-manager, only if you enable TURNS (see the TURNS guide under
  Documentation).

## Quick start

```bash
helm repo add jitsi https://jitsi-contrib.github.io/jitsi-helm/
helm install myjitsi jitsi/jitsi-meet --set publicURL=https://meet.mydomain.com
```

Alternatively, install directly from the OCI registry (GitHub Container
Registry):

```bash
helm install myjitsi oci://ghcr.io/jitsi-contrib/jitsi-meet --set publicURL=https://meet.mydomain.com
```

OCI releases are signed with [cosign](https://github.com/sigstore/cosign)
(keyless). To verify a release before installing:

```bash
cosign verify ghcr.io/jitsi-contrib/jitsi-meet:<version> \
  --certificate-identity-regexp '^https://github.com/jitsi-contrib/jitsi-helm/' \
  --certificate-oidc-issuer https://token.actions.githubusercontent.com
```

## Exposing your Jitsi Meet installation

JVB must be reachable by all participants (typically on a public IP), and the
best approach depends on your cluster. The chart supports several options:
LoadBalancer, NodePort, hostPort (including auto-detected node IP and port
ranges), hostNetwork, and ingress TCP/UDP forwarding.

See the [Exposing guide](/docs/guides/exposing.md) for all options and examples.

## Recording and streaming support

Jibri lets Jitsi Meet users record meetings and live-stream them (e.g. to
YouTube). Enable it under the `jibri` key, with options for single-use mode,
multiple instances, local recording, live streaming, and persistent storage.

See the [Recording and streaming guide](/docs/guides/recording.md) for the full
configuration.

## Transcription support

The chart supports near real-time transcription (subtitles). The current path is
bridge-based: Jicofo tells JVB which transcription service a conference should
use. JVB streams the audio to `opus-transcriber-proxy` and the proxy relays it
to a speech-to-text provider (OpenAI, Deepgram, Gemini) or to your own
OpenAI-compatible service. Enabling it takes `opusTranscriberProxy.enabled` plus
the `force_async_transcription` Prosody module, which the chart does not switch
on for you.

See the
[custom AI service guide](/docs/guides/opus-transcriber-proxy-custom-ai.md) for
the full configuration.

The older Transcriber (Jigasi in transcriber mode) with
[Skynet](https://github.com/jitsi/skynet) or another Jigasi-supported backend
still works, but it is deprecated upstream. See the
[Transcriber and Skynet guide](/docs/guides/transcriber-skynet.md).

## Scaling your installation

Jitsi Web, Jibri, and Coturn are stateless and scale freely via `replicaCount`.
JVB scales via the OCTO relay feature, which spreads the participants of one
meeting across multiple bridges. It can also follow the load on its own, and it
drains before a bridge is removed so that scaling in costs no calls.

See the [Scaling guide](/docs/guides/scaling.md) for replica settings, the OCTO
configuration, autoscaling, draining, and how to test it.

## Adding custom Prosody plugins

Extend Prosody with extra plugins by mounting them via `prosody.extraVolumes` /
`extraVolumeMounts`. Modules from the jitsi-contrib/prosody-plugins collection
already ship in the official `ghcr.io/jitsi/prosody` image.

See the [Prosody plugins guide](/docs/guides/prosody-plugins.md) for an example.

## Documentation

Each feature section above links to its detailed guide. See also:

- [TURN and TURNS on port 443](/docs/guides/turns.md)
- [Security hardening](/docs/guides/security.md)
- [Custom CA certificates](/docs/guides/custom-ca.md)
- [Troubleshooting](/docs/guides/troubleshooting.md)
- [Upgrading](/docs/guides/upgrading.md)
- [Sample values files](/docs/samples/)
- [All guides](/docs/guides/)

For the full configuration reference, see [values.yaml](/values.yaml).
